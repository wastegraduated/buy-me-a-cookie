BUY ME A COOKIE — QUICK START

1. Extract cookie-support-website.zip (if you downloaded the ZIP).
2. Open the folder.
3. Double-click index.html to run it in your browser.
4. Edit index.html in VS Code or any text editor to change the wording, colours, and prices.

This is a static front-end demo. The support buttons only show a demo message; they do not collect or process payments. Before taking real payments, connect a legitimate payment provider and use its official hosted checkout flow. Do not collect card details yourself.

To publish for free, you can deploy this folder with GitHub Pages or another static hosting service. The free host URL and provider terms may vary.
